A Pen created at CodePen.io. You can find this one at http://codepen.io/Dpappy/pen/zqOyNY.

 Full docs can be found at http://simpleweatherjs.com.

Forked from [James Fleeting](http://codepen.io/fleeting/)'s Pen [simpleWeather.demo.js](http://codepen.io/fleeting/pen/wHism/).